export const Utils = {
  init: function() {
    this.SetDataBackgrounds();
    this.SetHeroToActiveOnLoad();
    this.SetNavBackgroundOnCMSView();
  },
  SetDataBackgrounds: () => {
    $('[data-background]').each(function() {
      $(this).css('background-image', 'url('+ $(this).attr('data-background') + ')');
    });
  },
  SetHeroToActiveOnLoad: () => {
    setTimeout(() => {
      $('.hero-item').addClass('active');
    }, 400);
  },
  SetNavBackgroundOnCMSView: () => {
    if (window.frameElement && window.frameElement.id === 'STML_frame') {
      const header = document.querySelector('#header-id');
      if (header) {
        header.style.backgroundColor = '#000000';
      }
    }
  }
}