jQuery('.slick').slick({
	lazyLoad: 'ondemand',
	slidesToShow: 1,
	autoplay: 0,
	dots: true,
	arrows: false
});
