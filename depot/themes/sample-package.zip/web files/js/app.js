'use strict';

// Packages
import 'jquery';
import '@popperjs/core';
import 'bootstrap';
import 'slick-carousel';
import 'jquery-validation';

// Components
import Utils from './utils/utils';

$(function() {
  new Utils();
});