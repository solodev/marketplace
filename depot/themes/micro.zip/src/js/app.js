'use strict';

// Packages
import 'jquery';
import '@popperjs/core';
import 'bootstrap';
import 'jquery-validation';

// Components
import Utils from './utils/utils';
import Validation from './components/validation';

$(function() {
  new Utils();
  new Validation();
});