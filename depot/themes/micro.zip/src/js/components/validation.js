export default class Validation {
  constructor() {
    const form = document.getElementById('serverless-form');

    if (form) {
      this.form = form;
      this.initValidation();
      this.thankYouMessage();
    }
  }
  initValidation() {
    $(function() {
      jQuery.validator.addMethod('phone_rule', function(value, element) {
        if (/^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/.test(value)) {
          return true;
        };
      }, 'Please enter a valid phone number without dashes or periods.'); 
      
      jQuery.validator.addMethod('email_rule', function(value, element) {
        if (/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/.test(value)) {
          return true;
        };
      }, 'Please enter a valid email address.');
      
      $('#serverless-form').validate({
        rules: {
          'first_name': {
            required: true
          },
          'last_name': {
            required: true
          },
          'company': {
            required: true
          },
          'title': {
            required: true,
          },
          'email': {
            required: true,
            email_rule: true
          },
          'phone': {
            required: true,
            phone_rule: true
          },
        },
        messages: {
          'first_name': "Please specify your first name",
          'last_name': "Please specify your last name",
          'company': "Please specify your company name",
          'title': "Please specify your job title",
          'email': "Please enter a valid email address",
          'phone': "Please enter a valid phone number",
        }
      });
    }); 
  }
  thankYouMessage() {
    
    this.form.addEventListener('submit', (event) =>  {
      console.log(event);
      event.preventDefault();
      this.form.classList.add('d-none');
      console.log(document.querySelector('.message'));
      document.querySelector('.message').classList.remove('d-none');
  });
  }
}