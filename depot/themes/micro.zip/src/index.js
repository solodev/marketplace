/**
 * This file is only for dev environment!!! 
 * So we can work on the theme locally.
**/			

import '../src/scss/app.scss';
import './js/app';