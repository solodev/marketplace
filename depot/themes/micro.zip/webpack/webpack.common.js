'use strict';

const path = require('path');
const webpack = require('webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = (env, argv) => {
  const isDev = argv.mode === 'development';
  
  return {
    context: path.resolve(__dirname, '../src'),
    entry: './index.js',
    output: {
      path: path.resolve(__dirname, '../build'),
      filename: '_/js/[name].js',
      assetModuleFilename: '_/images/[name][ext]',
      clean: true,
    },
    resolve: {
      extensions: ['.js', '.scss'],
    },
    module: {
      rules: [
        {
          test: /\.js$/,
          exclude: /node_modules/,
          use: {
            loader: 'babel-loader',
            options: {
              presets: ['@babel/preset-env']
            }
          }
        },
        {
          test: require.resolve('jquery'),
          use: [
            {
              loader: 'expose-loader',
              options: {
                exposes: ['$', 'jQuery']
              }
            }
          ]
        },
        {
          test: /\.(woff|woff2|eot|ttf|otf)$/i,
          type: 'asset/resource',
          generator: {
            filename: '_/fonts/[name][ext]'
          },
        },
        {
          test: /\.(jpg|jpeg|gif|png|svg)$/,
          type: 'asset/resource',
        },
        {
          test: /\.s[ac]ss$/i,
          use: [
            'style-loader',
            'css-loader',
            'sass-loader',
          ],
        },
      ]
    },
    plugins: [
      new webpack.ProvidePlugin({
        jQuery: 'jquery',
        $: 'jquery',
        jquery: 'jquery'
      }),
      new HtmlWebpackPlugin({
        title: 'Solodev Micro Theme',
        template: './index.html',
        isDev: isDev,
      }),
      new CopyWebpackPlugin({
        patterns: [
          { from: path.resolve(__dirname, '../www/_/images'), to: '_/images' }
        ],
      }),
      new CleanWebpackPlugin(),
      new webpack.DefinePlugin({
        'process.env.NODE_ENV': JSON.stringify(argv.mode),
        'IS_DEV': JSON.stringify(isDev),
      }),
    ],
    stats: {
      children: true,
    },
  };
};
