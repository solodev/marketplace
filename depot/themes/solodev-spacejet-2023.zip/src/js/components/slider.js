export default class Slider {
  
  constructor() {
    const heroSlider = document.querySelector('.hero-slider');

    if (heroSlider) {
      this.initHeroSlider();
    }
  }
  initHeroSlider() {
    if ($('.hero-slider')) {
      $('.hero-slider').slick({
        arrows: false,
        dots: false,
        fade: true,
        autoplay: false,
        autoplaySpeed: 5000,
      });
      $('.header-slider--prev').each(function() {
        $(this).on('click', function() {
          $('.header-slider').slick('slickPrev');
        });
      });
      $('.header-slider--next').each(function() {
        $(this).on('click', function() {
          $('.header-slider').slick('slickNext');
        });
      });
      /* Accessibility Labels for Sliders */
      $('.hero-slider .slick-track').attr('aria-label', 'Homepage Slider');
    }
  }
}