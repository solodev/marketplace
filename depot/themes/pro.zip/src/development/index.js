'use strict';

/**
 * This file is only for dev environment!!! 
 * So we can work on the theme locally.
**/			

import '../scss/app.scss';
import '../js/app';